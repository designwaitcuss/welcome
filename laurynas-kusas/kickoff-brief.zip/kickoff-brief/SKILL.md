---
name: kickoff-brief
description: Writes a one-page project brief for a founder's MyMatrix kickoff call with Lauri. Drafts it from what you already know about the founder and their project (memory, earlier chats, files, links), asks only for what's missing, then hands over one brief to send to Lauri. Use when the user says "kickoff brief", "brief Lauri", "MyMatrix kickoff", or wants to get ready for their first call with Lauri.
---

# MyMatrix kickoff brief

The person you're talking to just took a founding seat in MyMatrix Community. Before their kickoff call, Lauri wants a rough picture of their project, so the hour goes to the work and not to the basics. Your job is to write that picture as one short brief they can send him.

It's a starting point, not an exam. A rough, honest brief beats a polished one.

## How to work

1. **Start from what you already know.** Look through your memory of this person, earlier chats, project files, documents in this conversation and any links they share. Draft every section you can from that. If you can open web pages, read their website.
2. **Show the draft, then ask only what's missing.** One question at a time, 8 questions at most. Plain words, no jargon. If they don't know or don't want to say, write "not known yet" and move on.
3. **Check it with them.** Show the full brief and ask if anything is wrong or missing. Fix what they say.
4. **Hand it over.** Give the final brief in one block they can copy, and tell them to send it to Lauri in their chat with him before the kickoff.

## Rules

- Never invent anything. Numbers, prices, customers and dates come only from the person or their files. If you're unsure, ask or write "not known yet".
- Don't give advice, a plan or a diagnosis. That's what the kickoff is for. Your job is the picture, not the fix.
- Leave out anything private. No passwords, keys, bank details, or customer names, emails and phone numbers. Counts are enough ("12 customers").
- Write the brief in the language the person writes to you.
- Keep it to about one page.
- If more than one person works on the project, each of them can run this. Put who filled it in at the top.

## The brief

```
# Kickoff brief, [project name]
Filled in by [name], [date]

## The project in one line

## The team
Who is on it and who does what.

## What it is and who it's for

## Links
Website, socials, deck, anything Lauri should open.

## Offer and price
What people buy and what it costs. "No offer yet" is a fine answer.

## Where it stands
Customers or payments so far, leads in progress, revenue. Real numbers only.

## What you've tried

## Where you're stuck

## What the next 30 days should bring

## One thing Lauri should know
```
